
$(function() {
 $( ".circle" ).hover(function() {
   $(this).css("background", "red");
 },function() {
   $(this).css("background", "gold");
 });
});